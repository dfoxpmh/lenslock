INSERT IGNORE INTO `#__rsfirewall_feeds` (`id`, `url`, `limit`, `ordering`, `published`) VALUES
(1, 'http://feeds.joomla.org/JoomlaSecurityNews', 5, 1, 0);
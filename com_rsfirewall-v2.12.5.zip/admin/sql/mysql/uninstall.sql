DROP TABLE IF EXISTS 
`#__rsfirewall_configuration`,
`#__rsfirewall_exceptions`,
`#__rsfirewall_feeds`,
`#__rsfirewall_hashes`,
`#__rsfirewall_ignored`,
`#__rsfirewall_lists`,
`#__rsfirewall_logs`,
`#__rsfirewall_offenders`,
`#__rsfirewall_signatures`,
`#__rsfirewall_snapshots`;
CREATE TABLE [#__rsfirewall_ignored] (
  [path] text NOT NULL,
  [type] varchar(255) NOT NULL
);
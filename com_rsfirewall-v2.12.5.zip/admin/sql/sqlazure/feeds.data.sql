INSERT INTO [#__rsfirewall_feeds] ([url], [limit], [ordering], [published]) VALUES
('http://feeds.joomla.org/JoomlaSecurityNews', 5, 1, 0);